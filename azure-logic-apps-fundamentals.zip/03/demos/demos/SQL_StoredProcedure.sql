/*    ==Scripting Parameters==

    Source Database Engine Edition : Microsoft Azure SQL Database Edition
    Source Database Engine Type : Microsoft Azure SQL Database

    Target Database Engine Edition : Microsoft Azure SQL Database Edition
    Target Database Engine Type : Microsoft Azure SQL Database
*/

/****** Object:  StoredProcedure [dbo].[Insert_RewardsDetails]    Script Date: 2/21/2018 5:15:48 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:      Stephen W Thomas
-- Create Date: 1-24-2018
-- Description: Inserts customer reward data into the system
-- =============================================
CREATE PROCEDURE [dbo].[Insert_RewardsDetails]
(
	@Id int,
	@RewardsNumber nvarchar(50),
	@Amount nvarchar(50)
)
AS
BEGIN
    SET NOCOUNT ON

	INSERT INTO [dbo].[Rewards]
           ([Id]
           ,[RewardsNumber]
           ,[Amount])
     VALUES
           (@Id
           ,@RewardsNumber
           ,@Amount)
END
GO


