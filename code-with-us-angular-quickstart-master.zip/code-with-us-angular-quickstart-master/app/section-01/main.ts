import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { AppModule } from './app.module';

// Start here --> AppModule
platformBrowserDynamic().bootstrapModule(AppModule);
